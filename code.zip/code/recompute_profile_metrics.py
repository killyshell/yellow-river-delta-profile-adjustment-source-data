"""Recompute six metrics when the private original-format NPZ is supplied."""
from pathlib import Path
import argparse, csv
def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    import numpy as np
    a=np.load(args.input,allow_pickle=False);rows=[]
    for n in range(1,37):
        w=a[f'断面{n:02}积分权重米'];length=w.sum()
        for start,end in [(2009,2010),(2010,2011),(2011,2014),(2009,2014)]:
            v=a[f'{end}年断面{n:02}床面米']-a[f'{start}年断面{n:02}床面米'];mean=w@v/length;d=w@np.maximum(v,0)/length;e=w@np.maximum(-v,0)/length;g=d+e;h=w@abs(v-mean)/length
            rows.append(dict(profile=n,start=start,end=end,L_m=length,N_m=mean,D_m=d,E_m=e,G_m=g,C=1-abs(mean)/g if g>0 else '',H_m=h))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(f'Recomputed {len(rows)} profile-interval records at {args.output}')
if __name__=='__main__':main()
