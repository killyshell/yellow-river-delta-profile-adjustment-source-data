"""Rebuild key aggregate results from the public CSVs; standard library only."""
from pathlib import Path
import argparse, csv, json, statistics
ROOT=Path(__file__).resolve().parents[1]
def read(name):
    with (ROOT/'data'/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('results'));args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    rows=[r for r in read('profile_metrics.csv') if r['start']=='2009' and r['end']=='2014']
    summary={'interval':'2009-2014','profiles':len(rows),'medians':{k:statistics.median(float(r[k]) for r in rows) for k in ['N_m','G_m','H_m']},'profiles_with_both_signs':sum(bool(r['centroid_separation_km']) for r in rows),'median_centroid_separation_km':statistics.median(float(r['centroid_separation_km']) for r in rows if r['centroid_separation_km'])}
    null=read('observation_error_envelopes.csv');summary['H_exceedance_counts']={s:sum(r['exceeds_H_envelope']=='True' for r in null if r['scenario']==s) for s in ['Low','Intermediate','High']}
    (args.output/'headline_results.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    sectors=[]
    for sector in dict.fromkeys(r['sector'] for r in rows):
        q=[r for r in rows if r['sector']==sector]
        sectors.append({'sector':sector,'profiles':len(q),**{'median_'+k:statistics.median(float(r[k]) for r in q) for k in ['N_m','G_m','C','H_m']}})
    with (args.output/'full_period_sector_summary.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(sectors[0]));writer.writeheader();writer.writerows(sectors)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
