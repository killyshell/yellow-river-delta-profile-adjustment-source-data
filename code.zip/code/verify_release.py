"""Validate a release without third-party Python dependencies."""
from pathlib import Path
import csv, hashlib, json, math, statistics, sys

ROOT=Path(__file__).resolve().parents[1]
def read(name):
    with (ROOT/'data'/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def close(a,b,tol=1e-10):assert math.isclose(float(a),float(b),rel_tol=tol,abs_tol=tol),(a,b)
def main():
    manifest=json.loads((ROOT/'metadata/file_manifest.json').read_text(encoding='utf-8'))
    for item in manifest:
        path=ROOT/item['path'];assert path.is_file(),item['path']
        assert path.stat().st_size==item['bytes'],item['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],item['path']
    checksums={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (ROOT/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()}
    assert set(checksums)=={r['path'] for r in manifest}
    for item in manifest:assert checksums[item['path']]==item['sha256']
    catalog=json.loads((ROOT/'metadata/table_catalog.json').read_text(encoding='utf-8'))
    for item in catalog:
        rows=read(Path(item['file']).name);assert len(rows)==item['rows'],item['file']
        assert list(rows[0])==item['columns'],item['file']
    rows=read('profile_metrics.csv');assert len(rows)==144
    assert len({(r['profile'],r['start'],r['end']) for r in rows})==144
    assert all(1<=int(r['profile'])<=36 for r in rows)
    for r in rows:
        n,d,e,g,c,h=[float(r[x]) for x in ['N_m','D_m','E_m','G_m','C','H_m']]
        close(n,d-e);close(g,d+e);close(c,1-abs(n)/g)
        assert min(d,e,g,h)>=0 and g+1e-10>=abs(n) and -1e-10<=c<=1+1e-10
        close(sum(float(r[x]) for x in ['positive_length_fraction','negative_length_fraction','zero_length_fraction']),1)
    full=[r for r in rows if r['start']=='2009' and r['end']=='2014'];assert len(full)==36
    medians={k:statistics.median(float(r[k]) for r in full) for k in ['N_m','G_m','H_m']}
    for k,v in zip(['N_m','G_m','H_m'],[-.153,.346,.272]):close(medians[k],v,tol=.00051)
    e=read('observation_error_envelopes.csv');counts={s:sum(r['exceeds_H_envelope']=='True' for r in e if r['scenario']==s) for s in ['Low','Intermediate','High']}
    assert counts==dict(Low=33,Intermediate=19,High=5),counts
    assert len(e)==108
    bands=read('depth_band_diagnostics.csv');lookup={(r['profile'],r['depth_band_m']):float(r['internal_departure_m']) for r in bands if r['start']=='2009' and r['end']=='2014'}
    matched=[n for n in range(1,37) if (str(n),'0-5') in lookup and (str(n),'10-15') in lookup]
    assert len(matched)==24 and all(lookup[str(n),'0-5']>lookup[str(n),'10-15'] for n in matched)
    sens=read('grid_gap_sensitivity.csv');assert len(sens)==324
    assert sum(r['support_status']=='valid' for r in sens)==319
    assert all(r['H_m']=='' for r in sens if r['support_status']=='no_common_support')
    pairs=read('core_waterline_bathymetry_pairs.csv');assert len(pairs)==144
    assert sum(r['has_annual_waterline_pair']=='True' for r in pairs)==42
    assert len(read('annual_waterline_inventory.csv'))==496
    for r in read('joint_classification_counts.csv'):
        if r['stable_pairs']=='0':assert r['joint_fraction_stable_pairs']==''
    # Independent monthly aggregation check against every matched interval.
    monthly=read('monthly_wave_context.csv');matched_env=read('matched_environmental_intervals.csv')
    grids={'Northern lobe':'Northern','Gudong':'Central','Mouth sector':'Southeastern','Southern extension':'Southeastern'}
    for r in matched_env:
        month=10 if r['boundary']=='October' else 1
        start=(int(r['start']),month);end=(int(r['end']),month)
        q=[x for x in monthly if x['reference_grid']==grids[r['sector']] and start<=(int(x['year']),int(x['month']))<end]
        hours=sum(float(x['wave_hours']) for x in q)
        close(sum(float(x['wave_proxy_sum_m2_s']) for x in q)/hours,r['wave_proxy_m2_s'])
        close(sum(float(x['high_wave_hours']) for x in q)/hours,r['high_wave_fraction'])
    print(json.dumps({'status':'passed','files_verified':len(manifest),'tables':len(catalog),'profile_intervals':len(rows),'median_NGH_m':medians,'H_envelope_exceedance_counts':counts,'paired_depth_profiles':len(matched),'annual_waterline_pairs':42,'environmental_rows_checked':len(matched_env)},indent=2))
if __name__=='__main__':main()
